package sample.spring.chapter03.bankapp.base;

public class WebServiceInvoker {

}
