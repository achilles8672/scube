package sample.spring.chapter04.bankapp.domain;

public class AccountStatement {

}
