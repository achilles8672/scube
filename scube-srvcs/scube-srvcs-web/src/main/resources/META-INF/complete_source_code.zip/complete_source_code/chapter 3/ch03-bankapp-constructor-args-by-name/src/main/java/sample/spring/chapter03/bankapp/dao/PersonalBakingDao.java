package sample.spring.chapter03.bankapp.dao;

import sample.spring.chapter03.bankapp.domain.BankStatement;

public interface PersonalBakingDao {
	BankStatement getMiniStatement();
}
