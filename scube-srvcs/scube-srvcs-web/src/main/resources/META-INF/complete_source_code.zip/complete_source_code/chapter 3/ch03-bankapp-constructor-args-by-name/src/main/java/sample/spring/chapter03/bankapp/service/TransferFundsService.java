package sample.spring.chapter03.bankapp.service;

public interface TransferFundsService {
	public void transferFunds();
}
