package sample.spring.chapter04.bankapp.event;

public interface EventSender {
	void sendEvent(Event e);
}
