package sample.spring.chapter04.bankapp.service;

public interface CustomerRequestService {
	void submitRequest(String requestType, String requestDescription);
}
